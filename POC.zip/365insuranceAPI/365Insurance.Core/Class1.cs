﻿namespace _365Insurance.Core
{
    public class Class1
    {

    }
}