﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace _365Insurance.Core.Domain.Models;

public partial class Insure247DbContext : DbContext
{
    public Insure247DbContext()
    {
    }

    public Insure247DbContext(DbContextOptions<Insure247DbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<FirstPartyRequestQuotation> FirstPartyRequestQuotations { get; set; }

    public virtual DbSet<InsuranceCompanyTransaction> InsuranceCompanyTransactions { get; set; }

    public virtual DbSet<PolicyConfirmation> PolicyConfirmations { get; set; }

    public virtual DbSet<PucCertificate> PucCertificates { get; set; }

    public virtual DbSet<RtoMa> RtoMas { get; set; }

    public virtual DbSet<StateMa> StateMas { get; set; }

    public virtual DbSet<TpRate> TpRates { get; set; }

    public virtual DbSet<VehicleAge> VehicleAges { get; set; }

    public virtual DbSet<VehicleAgentCode> VehicleAgentCodes { get; set; }

    public virtual DbSet<VehicleCompany> VehicleCompanies { get; set; }

    public virtual DbSet<VehicleCubicCapicity> VehicleCubicCapicities { get; set; }

    public virtual DbSet<VehicleFueltype> VehicleFueltypes { get; set; }

    public virtual DbSet<VehicleInfo> VehicleInfos { get; set; }

    public virtual DbSet<VehicleInsuranceCompany> VehicleInsuranceCompanies { get; set; }

    public virtual DbSet<VehicleInsuranceCompanyMapping> VehicleInsuranceCompanyMappings { get; set; }

    public virtual DbSet<VehicleModel> VehicleModels { get; set; }

    public virtual DbSet<VehicleType> VehicleTypes { get; set; }

    public virtual DbSet<VehicleVariant> VehicleVariants { get; set; }

//    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
//        => optionsBuilder.UseSqlServer("Data Source=MUM-NIRAJB1;Initial Catalog=insure_247_db;Integrated Security=True;TrustServerCertificate=true");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<FirstPartyRequestQuotation>(entity =>
        {
            entity.HasKey(e => e.FpReqQuotationId).HasName("PK_first_party_doc");

            entity.ToTable("first_party_request_quotation");

            entity.Property(e => e.FpReqQuotationId).HasColumnName("fp_req_quotation_id");
            entity.Property(e => e.AgentCodeId).HasColumnName("agent_code_id");
            entity.Property(e => e.Comments)
                .HasMaxLength(1000)
                .HasColumnName("comments");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate)
                .HasColumnType("datetime")
                .HasColumnName("created_date");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .HasColumnName("email");
            entity.Property(e => e.IdvValue)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("idv_value");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.MobileNo)
                .HasMaxLength(10)
                .HasColumnName("mobile_no");
            entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");
            entity.Property(e => e.ModifiedDate)
                .HasColumnType("datetime")
                .HasColumnName("modified_date");
            entity.Property(e => e.Name)
                .HasMaxLength(500)
                .HasColumnName("name");
            entity.Property(e => e.PreviousInsurance)
                .HasMaxLength(1000)
                .HasColumnName("previous_insurance");
            entity.Property(e => e.RcBack)
                .HasMaxLength(1000)
                .HasColumnName("rc_back");
            entity.Property(e => e.RcFront)
                .HasMaxLength(1000)
                .HasColumnName("rc_front");
        });

        modelBuilder.Entity<InsuranceCompanyTransaction>(entity =>
        {
            entity.HasKey(e => e.InsuranceCompanyTrancId);

            entity.ToTable("insurance_company_transaction");

            entity.Property(e => e.InsuranceCompanyTrancId).HasColumnName("insurance_company_tranc_id");
            entity.Property(e => e.AgeId).HasColumnName("age_id");
            entity.Property(e => e.AgentCodeId).HasColumnName("agent_code_id");
            entity.Property(e => e.CashBack)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("cash_back");
            entity.Property(e => e.CashbackPercent).HasColumnName("cashback_percent");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate)
                .HasColumnType("datetime")
                .HasColumnName("created_date");
            entity.Property(e => e.CubicCapicityId).HasColumnName("cubic_capicity_id");
            entity.Property(e => e.InsuranceAmount)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("insurance_amount");
            entity.Property(e => e.InsuranceCompanyId).HasColumnName("insurance_company_id");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");
            entity.Property(e => e.ModifiedDate)
                .HasColumnType("datetime")
                .HasColumnName("modified_date");
            entity.Property(e => e.RtoId).HasColumnName("rto_id");
            entity.Property(e => e.StateId).HasColumnName("state_id");
            entity.Property(e => e.TppId).HasColumnName("tpp_id");
            entity.Property(e => e.VehicleTypeId).HasColumnName("vehicle_type_id");
        });

        modelBuilder.Entity<PolicyConfirmation>(entity =>
        {
            entity.ToTable("policy_confirmation");

            entity.Property(e => e.PolicyConfirmationId).HasColumnName("policy_confirmation_id");
            entity.Property(e => e.AadharCard)
                .HasMaxLength(1000)
                .HasColumnName("aadhar_card");
            entity.Property(e => e.Comments)
                .HasMaxLength(1000)
                .HasColumnName("comments");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate)
                .HasColumnType("datetime")
                .HasColumnName("created_date");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .HasColumnName("email");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.MobileNo)
                .HasMaxLength(10)
                .HasColumnName("mobile_no");
            entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");
            entity.Property(e => e.ModifiedDate)
                .HasColumnType("datetime")
                .HasColumnName("modified_date");
            entity.Property(e => e.Name)
                .HasMaxLength(500)
                .HasColumnName("name");
            entity.Property(e => e.PanCard)
                .HasMaxLength(1000)
                .HasColumnName("pan_card");
            entity.Property(e => e.RcCertificate)
                .HasMaxLength(1000)
                .HasColumnName("rc_certificate");
            entity.Property(e => e.VoterCard)
                .HasMaxLength(1000)
                .HasColumnName("voter_card");
        });

        modelBuilder.Entity<PucCertificate>(entity =>
        {
            entity.ToTable("puc_certificate");

            entity.Property(e => e.PucCertificateId).HasColumnName("puc_certificate_id");
            entity.Property(e => e.Comments)
                .HasMaxLength(1000)
                .HasColumnName("comments");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate)
                .HasColumnType("datetime")
                .HasColumnName("created_date");
            entity.Property(e => e.Email)
                .HasMaxLength(100)
                .HasColumnName("email");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.MobileNo)
                .HasMaxLength(10)
                .HasColumnName("mobile_no");
            entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");
            entity.Property(e => e.ModifiedDate)
                .HasColumnType("datetime")
                .HasColumnName("modified_date");
            entity.Property(e => e.Name)
                .HasMaxLength(500)
                .HasColumnName("name");
            entity.Property(e => e.RcCopy)
                .HasMaxLength(1000)
                .HasColumnName("rc_copy");
            entity.Property(e => e.VehicleCopy)
                .HasMaxLength(1000)
                .HasColumnName("vehicle_copy");
        });

        modelBuilder.Entity<RtoMa>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("rto_mas");

            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate)
                .HasColumnType("datetime")
                .HasColumnName("created_date");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");
            entity.Property(e => e.ModifiedDate)
                .HasColumnType("datetime")
                .HasColumnName("modified_date");
            entity.Property(e => e.RtoCode)
                .HasMaxLength(50)
                .HasColumnName("rto_code");
            entity.Property(e => e.RtoId)
                .ValueGeneratedOnAdd()
                .HasColumnName("rto_id");
            entity.Property(e => e.StateId).HasColumnName("state_id");
        });

        modelBuilder.Entity<StateMa>(entity =>
        {
            entity.HasKey(e => e.StateId);

            entity.ToTable("state_mas");

            entity.Property(e => e.StateId).HasColumnName("state_id");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate)
                .HasColumnType("datetime")
                .HasColumnName("created_date");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");
            entity.Property(e => e.ModifiedDate)
                .HasColumnType("datetime")
                .HasColumnName("modified_date");
            entity.Property(e => e.StateCode)
                .HasMaxLength(50)
                .HasColumnName("state_code");
            entity.Property(e => e.StateName)
                .HasMaxLength(50)
                .HasColumnName("state_name");
        });

        modelBuilder.Entity<TpRate>(entity =>
        {
            entity.HasKey(e => e.TppId);

            entity.ToTable("tp_rates");

            entity.Property(e => e.TppId).HasColumnName("tpp_id");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate)
                .HasColumnType("datetime")
                .HasColumnName("created_date");
            entity.Property(e => e.CubicCapicityId).HasColumnName("cubic_capicity_id");
            entity.Property(e => e.Driver)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("driver");
            entity.Property(e => e.FinalPremium)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("final_premium");
            entity.Property(e => e.FiveYearTp)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("five_year_tp");
            entity.Property(e => e.GstDriver)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("gst_driver");
            entity.Property(e => e.GstPassenger)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("gst_passenger");
            entity.Property(e => e.GstPcvTp)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("gst_pcv_tp");
            entity.Property(e => e.GstPersonalAccident)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("gst_personal_accident");
            entity.Property(e => e.GstTotal)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("gst_total");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");
            entity.Property(e => e.ModifiedDate)
                .HasColumnType("datetime")
                .HasColumnName("modified_date");
            entity.Property(e => e.NetPremimum)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("net_premimum");
            entity.Property(e => e.Passanger)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("passanger");
            entity.Property(e => e.PcvTp)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("pcv_tp");
            entity.Property(e => e.PerPassenger)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("per_passenger");
            entity.Property(e => e.PersonalAccindent)
                .HasColumnType("decimal(18, 0)")
                .HasColumnName("personal_accindent");
            entity.Property(e => e.VehicleType).HasColumnName("vehicle_type");
        });

        modelBuilder.Entity<VehicleAge>(entity =>
        {
            entity.HasKey(e => e.AgeId);

            entity.ToTable("vehicle_age");

            entity.Property(e => e.AgeId).HasColumnName("age_id");
            entity.Property(e => e.Age)
                .HasMaxLength(50)
                .HasColumnName("age");
            entity.Property(e => e.AgeRangeMax).HasColumnName("age_range_max");
            entity.Property(e => e.AgeRangeMin).HasColumnName("age_range_min");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate)
                .HasColumnType("datetime")
                .HasColumnName("created_date");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");
            entity.Property(e => e.ModifiedDate)
                .HasColumnType("datetime")
                .HasColumnName("modified_date");
            entity.Property(e => e.State).HasColumnName("state");
        });

        modelBuilder.Entity<VehicleAgentCode>(entity =>
        {
            entity.HasKey(e => e.AgentCodeId);

            entity.ToTable("vehicle_agent_code");

            entity.Property(e => e.AgentCodeId).HasColumnName("agent_code_id");
            entity.Property(e => e.AgentCode)
                .HasMaxLength(50)
                .HasColumnName("agent_code");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate)
                .HasColumnType("datetime")
                .HasColumnName("created_date");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");
            entity.Property(e => e.ModifiedDate)
                .HasColumnType("datetime")
                .HasColumnName("modified_date");
            entity.Property(e => e.State).HasColumnName("state");
        });

        modelBuilder.Entity<VehicleCompany>(entity =>
        {
            entity.HasKey(e => e.CompanyId);

            entity.ToTable("vehicle_company");

            entity.Property(e => e.CompanyId).HasColumnName("company_id");
            entity.Property(e => e.CompanyLogo)
                .HasMaxLength(500)
                .HasColumnName("company_logo");
            entity.Property(e => e.CompanyName)
                .HasMaxLength(50)
                .HasColumnName("company_name");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate)
                .HasColumnType("datetime")
                .HasColumnName("created_date");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");
            entity.Property(e => e.ModifiedDate)
                .HasColumnType("datetime")
                .HasColumnName("modified_date");
            entity.Property(e => e.State).HasColumnName("state");
            entity.Property(e => e.VehicleType).HasColumnName("vehicle_type");
        });

        modelBuilder.Entity<VehicleCubicCapicity>(entity =>
        {
            entity.HasKey(e => e.CubicCapicityId);

            entity.ToTable("vehicle_cubic_capicity");

            entity.Property(e => e.CubicCapicityId).HasColumnName("cubic_capicity_id");
            entity.Property(e => e.CcGcwRangeMax).HasColumnName("cc_gcw_range_max");
            entity.Property(e => e.CcGcwRangeMin).HasColumnName("cc_gcw_range_min");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate)
                .HasColumnType("datetime")
                .HasColumnName("created_date");
            entity.Property(e => e.CubicCapicityName)
                .HasMaxLength(500)
                .HasColumnName("cubic_capicity_name");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");
            entity.Property(e => e.ModifiedDate)
                .HasColumnType("datetime")
                .HasColumnName("modified_date");
            entity.Property(e => e.State).HasColumnName("state");
            entity.Property(e => e.Unit)
                .HasMaxLength(50)
                .HasColumnName("unit");
            entity.Property(e => e.VehicleTypeId).HasColumnName("vehicle_type_id");
        });

        modelBuilder.Entity<VehicleFueltype>(entity =>
        {
            entity.HasKey(e => e.FueltypeId);

            entity.ToTable("vehicle_fueltype");

            entity.Property(e => e.FueltypeId).HasColumnName("fueltype_id");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate)
                .HasColumnType("datetime")
                .HasColumnName("created_date");
            entity.Property(e => e.FueltypeName)
                .HasMaxLength(50)
                .HasColumnName("fueltype_name");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");
            entity.Property(e => e.ModifiedDate)
                .HasColumnType("datetime")
                .HasColumnName("modified_date");
            entity.Property(e => e.State).HasColumnName("state");
        });

        modelBuilder.Entity<VehicleInfo>(entity =>
        {
            entity.ToTable("vehicle_info");

            entity.Property(e => e.VehicleinfoId).HasColumnName("vehicleinfo_id");
            entity.Property(e => e.CompanyId).HasColumnName("company_id");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate)
                .HasColumnType("datetime")
                .HasColumnName("created_date");
            entity.Property(e => e.FueltypeId).HasColumnName("fueltype_id");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.ManufacturingYear).HasColumnName("manufacturing_year");
            entity.Property(e => e.ModelId).HasColumnName("model_id");
            entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");
            entity.Property(e => e.ModifiedDate)
                .HasColumnType("datetime")
                .HasColumnName("modified_date");
            entity.Property(e => e.RtoCode).HasColumnName("rto_code");
            entity.Property(e => e.State).HasColumnName("state");
            entity.Property(e => e.StateCode)
                .HasMaxLength(2)
                .HasColumnName("state_code");
        });

        modelBuilder.Entity<VehicleInsuranceCompany>(entity =>
        {
            entity.HasKey(e => e.InsuranceCompanyId);

            entity.ToTable("vehicle_insurance_company");

            entity.Property(e => e.InsuranceCompanyId).HasColumnName("insurance_company_id");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate)
                .HasColumnType("datetime")
                .HasColumnName("created_date");
            entity.Property(e => e.InsuranceCompanyName)
                .HasMaxLength(500)
                .HasColumnName("insurance_company_name");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");
            entity.Property(e => e.ModifiedDate)
                .HasColumnType("datetime")
                .HasColumnName("modified_date");
            entity.Property(e => e.State).HasColumnName("state");
        });

        modelBuilder.Entity<VehicleInsuranceCompanyMapping>(entity =>
        {
            entity.HasKey(e => e.VehicleInsuranceMappingId);

            entity.ToTable("vehicle_insurance_company_mapping");

            entity.Property(e => e.VehicleInsuranceMappingId).HasColumnName("vehicle_insurance_mapping_id");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate)
                .HasColumnType("datetime")
                .HasColumnName("created_date");
            entity.Property(e => e.InsuranceCompanyId).HasColumnName("insurance_company_id");
            entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");
            entity.Property(e => e.ModifiedDate)
                .HasColumnType("datetime")
                .HasColumnName("modified_date");
            entity.Property(e => e.VehicleinfoId).HasColumnName("vehicleinfo_id");
        });

        modelBuilder.Entity<VehicleModel>(entity =>
        {
            entity.HasKey(e => e.ModelId);

            entity.ToTable("vehicle_model");

            entity.Property(e => e.ModelId).HasColumnName("model_id");
            entity.Property(e => e.CompanyId).HasColumnName("company_id");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate)
                .HasColumnType("datetime")
                .HasColumnName("created_date");
            entity.Property(e => e.CubicCapicityId).HasColumnName("cubic_capicity_id");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.ModelName)
                .HasMaxLength(100)
                .HasColumnName("model_name");
            entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");
            entity.Property(e => e.ModifiedDate)
                .HasColumnType("datetime")
                .HasColumnName("modified_date");
            entity.Property(e => e.State).HasColumnName("state");
        });

        modelBuilder.Entity<VehicleType>(entity =>
        {
            entity.ToTable("vehicle_type");

            entity.Property(e => e.VehicleTypeId).HasColumnName("vehicle_type_id");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate)
                .HasColumnType("datetime")
                .HasColumnName("created_date");
            entity.Property(e => e.IsDeleted).HasColumnName("is_deleted");
            entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");
            entity.Property(e => e.ModifiedDate)
                .HasColumnType("datetime")
                .HasColumnName("modified_date");
            entity.Property(e => e.VehicleTypeName)
                .HasMaxLength(50)
                .HasColumnName("vehicle_type_name");
        });

        modelBuilder.Entity<VehicleVariant>(entity =>
        {
            entity.ToTable("vehicle_variant");

            entity.Property(e => e.VehicleVariantId).HasColumnName("vehicle_variant_id");
            entity.Property(e => e.CompanyId).HasColumnName("company_id");
            entity.Property(e => e.CreatedBy).HasColumnName("created_by");
            entity.Property(e => e.CreatedDate)
                .HasColumnType("datetime")
                .HasColumnName("created_date");
            entity.Property(e => e.CubicCapicityId).HasColumnName("cubic_capicity_id");
            entity.Property(e => e.ModelId).HasColumnName("model_id");
            entity.Property(e => e.ModifiedBy).HasColumnName("modified_by");
            entity.Property(e => e.ModifiedDate)
                .HasColumnType("datetime")
                .HasColumnName("modified_date");
            entity.Property(e => e.VariantName)
                .HasMaxLength(100)
                .HasColumnName("variant_name");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
