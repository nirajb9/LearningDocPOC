﻿using _365Insurance.Services.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace _365insuranceAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RequestQuotationController : ControllerBase
    {
        [HttpPost("SaveFPQuotation")]
        public IActionResult SaveFPQuotation([FromBody] RequestQuotationModel model)
        {
            var data = "";
            //if (model.IKmlId > 0)
            //{
            //    data = _kmlService.UpdateKml(model);
            //}
            //else
            //{
            //    data = _kmlService.AddKml(model);
            //}
            return Ok(data);
        }
    }
}
