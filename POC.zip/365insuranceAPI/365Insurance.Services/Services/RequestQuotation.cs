﻿using _365Insurance.Services.ViewModels;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace _365Insurance.Services.Services
{
    public class RequestQuotation
    {
        public string SaveFPQuotation(RequestQuotationModel model)
        {
            try
            {
              //  string ImgName = Image.imagename;
               
            }
            catch (Exception ex)
            {
               
            }

            return "success";
        }
    }
}
