﻿namespace _365Insurance.Services
{
    public class Class1
    {

    }
}