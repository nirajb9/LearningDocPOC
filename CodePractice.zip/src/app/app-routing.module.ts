import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContactComponent } from 'src/app/web/contact/contact.component';
import { HomeComponent } from 'src/app/web/home/home.component';
import { RegistrationComponent } from 'src/app/web/registration/registration.component';

const routes: Routes = [
   { path: '', component: HomeComponent },
  // { path: 'registration', component: RegistrationComponent },
  // { path: 'contact', component: ContactComponent },
  { path: 'web', loadChildren: () => import('../app/web/web.module').then(m=> m.WebModule)}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
