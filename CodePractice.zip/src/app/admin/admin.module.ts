import { Component, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SideNavigationComponent } from './side-navigation/side-navigation.component';
import { VehicleinfoAddComponent } from './vehicleinfo/vehicleinfo-add/vehicleinfo-add.component';
import { VehicleinfoListComponent } from './vehicleinfo/vehicleinfo-list/vehicleinfo-list.component';
import { VehicleinfoEditComponent } from './vehicleinfo/vehicleinfo-edit/vehicleinfo-edit.component';
import { Routes } from '@angular/router';

const routes: Routes = [
  {path : 'add-vehicleinfo', component: VehicleinfoAddComponent}
] ;

@NgModule({
  declarations: [
    SideNavigationComponent,
    VehicleinfoAddComponent,
    VehicleinfoListComponent,
    VehicleinfoEditComponent
  ],
  imports: [
    CommonModule
  ]
})
export class AdminModule { }
