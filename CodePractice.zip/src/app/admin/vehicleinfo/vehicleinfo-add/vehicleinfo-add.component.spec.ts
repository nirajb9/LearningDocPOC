import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VehicleinfoAddComponent } from './vehicleinfo-add.component';

describe('VehicleinfoAddComponent', () => {
  let component: VehicleinfoAddComponent;
  let fixture: ComponentFixture<VehicleinfoAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VehicleinfoAddComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VehicleinfoAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
