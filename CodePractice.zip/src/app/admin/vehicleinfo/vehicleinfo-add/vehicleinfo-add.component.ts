import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vehicleinfo-add',
  templateUrl: './vehicleinfo-add.component.html',
  styleUrls: ['./vehicleinfo-add.component.css']
})
export class VehicleinfoAddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
