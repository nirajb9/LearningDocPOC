import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VehicleinfoListComponent } from './vehicleinfo-list.component';

describe('VehicleinfoListComponent', () => {
  let component: VehicleinfoListComponent;
  let fixture: ComponentFixture<VehicleinfoListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VehicleinfoListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VehicleinfoListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
