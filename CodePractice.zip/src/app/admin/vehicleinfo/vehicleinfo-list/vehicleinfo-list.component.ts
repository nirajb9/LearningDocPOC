import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vehicleinfo-list',
  templateUrl: './vehicleinfo-list.component.html',
  styleUrls: ['./vehicleinfo-list.component.css']
})
export class VehicleinfoListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
