import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vehicleinfo-edit',
  templateUrl: './vehicleinfo-edit.component.html',
  styleUrls: ['./vehicleinfo-edit.component.css']
})
export class VehicleinfoEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
