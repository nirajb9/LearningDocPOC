import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VehicleinfoEditComponent } from './vehicleinfo-edit.component';

describe('VehicleinfoEditComponent', () => {
  let component: VehicleinfoEditComponent;
  let fixture: ComponentFixture<VehicleinfoEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VehicleinfoEditComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VehicleinfoEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
