export class Web {
}

export interface SearchParam {
    stateId: number;
    rTOId: number;
    vehicleTypeId: number;
    cCId: number;
    fuelTypeId: number;
    ageId: number;
}

export interface RequestQuotationModel {
    idvValue: number | null;
    name: string | null;
    mobileNo: string | null;
    email: string | null;
    comments: string | null;
    rcFront: UploadModel | null;
    rcBack: UploadModel | null;
    previousInsurance: UploadModel | null;
}

export interface UploadModel {
    name: string | null;
    contentType: string | null;
    content: string | null;
    fileSize: number | null;
}