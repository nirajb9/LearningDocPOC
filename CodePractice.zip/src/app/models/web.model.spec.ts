import { Web } from './web.model';

describe('Web', () => {
  it('should create an instance', () => {
    expect(new Web()).toBeTruthy();
  });
});
