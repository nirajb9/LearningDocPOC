import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { RequestQuotationModel, SearchParam } from '../models/web.model';

@Injectable({
  providedIn: 'root'
})
export class WebvehicleService {

  private url = "http://localhost:5161/api/";
  constructor(private httpclient : HttpClient) { }

  getVehicleCompany(VType : Number) {
    return this.httpclient.get(this.url + "VehicleCompany/GetAllVehicleCompany/"+ VType);
  }
  getModelByVCompanyId(VCompanyId : Number) {
    return this.httpclient.get(this.url + "VehicleModel/GetVehicleModelByCompanyId/" + VCompanyId);
  }
  getVarientByVModelId(VModelId : Number) {
    return this.httpclient.get(this.url + "VehicleVarient/GetVehicleVariantByModelId/" + VModelId);
  }
  getInsuranceDetails(vehicleVariantId : Number, stateCode : string, level: Number) {
    return this.httpclient.get(this.url + "VehicleInfo/GetInsuranceDetails/" + vehicleVariantId +"/"+stateCode +"/"+level);
  }
  getFuelType() {
    return this.httpclient.get(this.url + "Common/GetVehicleFueltypes/");
  }
  getVehicleType() {
    return this.httpclient.get(this.url + "Common/GetVehicleType/");
  }
  getVehicleAge() {
    return this.httpclient.get(this.url + "Common/GetVehicleAge/");
  }
  getVehicleCCByVehicleTYpe(vehicletypeid : number) {
    return this.httpclient.get(this.url + "VehicleCubicCapicity/GetAllVehicleCubicCapicityByVT/" + vehicletypeid);
  }
  getState() {
    return this.httpclient.get(this.url + "Common/GetState/");
  }
  getRTODetails(stateId : number) {
    return this.httpclient.get(this.url + "Common/GetRTODetails/" + stateId);
  }
  getInsuranceDetails1(searchParam : SearchParam) {
    return this.httpclient.post(this.url + "VehicleInfo/GetInsuranceDetails1/", searchParam);
  }
  SaveFPQuotation(requestQuotation : RequestQuotationModel) {
    return this.httpclient.post(this.url + "RequestQuotation/SaveFPQuotation/", requestQuotation);
  }
}
