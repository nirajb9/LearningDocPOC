import { TestBed } from '@angular/core/testing';

import { WebvehicleService } from './webvehicle.service';

describe('WebvehicleService', () => {
  let service: WebvehicleService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(WebvehicleService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
