import { TestBed } from '@angular/core/testing';

import { AdminvehicleService } from './adminvehicle.service';

describe('AdminvehicleService', () => {
  let service: AdminvehicleService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdminvehicleService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
