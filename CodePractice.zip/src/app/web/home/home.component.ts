import { Component, OnInit } from '@angular/core';
import { WebvehicleService } from 'src/app/services/webvehicle.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { RequestQuotationModel, SearchParam, UploadModel } from 'src/app/models/web.model';
import { AsyncSubject, Observable } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  VId : number = 1;
  CC_GVW : string = "CC";
  lstInsuranceInfo: any = [];
  isInsuranceDetails : boolean = false;
  VehicleAge : number = 0 ;
  lstVehicleAge : any = [];
  lstFuelType : any = [];
  lstVehicleType : any = [];
  FuelType : any ;
  lstVechicleCCGCW : any = [];
  VechicleCCGCW : number = 0;
  State : number = 1;
  lstState : any = [];
  RTO : number = 0;
  lstRTO : any = [];
  requestForFPQ : boolean = false;
  
  fileByteString1: string = "";
  fileName1: string = "";
  fileType1: string = "";

  fileByteString2: string = "";
  fileName2: string = "";
  fileType2: string = "";

  fileByteString3: string = "";
  fileName3: string = "";
  fileType3: string = "";
  
  idvValue : number = 0;
  name: string = ""; 
  mobileNo: string = "";
  email: string = "";
  comments: string = "";
  

  constructor(private service: WebvehicleService,
    private spinnerService: NgxSpinnerService) { }

  ngOnInit(): void {
    this.GetVehicleAge();
    this.GetFuelType();
    this.GetVehicleTypeType();
    this.GetState();
  }
  ChangeInsuranceType()
  {
    this.service.getVehicleCCByVehicleTYpe(this.VId).subscribe(res => {
      this.lstVechicleCCGCW = res;
    })
   
  }

  GetInsuranceDetails() {

   const searchParam : SearchParam = {
        ageId : this.VehicleAge,
        cCId : this.VechicleCCGCW,
        fuelTypeId : this.FuelType,
        rTOId : this.RTO,
        stateId : this.State,
        vehicleTypeId : this.VId
    }
    this.isInsuranceDetails = false;
    this.spinnerService.show();
    this.service.getInsuranceDetails1(searchParam)
      .subscribe(res => {
        console.log(res);
        this.lstInsuranceInfo = res;
        this.isInsuranceDetails = true;
        this.CloseSpiner();
      }
      )
    
  }
  CloseSpiner()
  {
    setTimeout(() => {
      this.spinnerService.hide();
    }, 1000);
  }

  GetVehicleAge() { 
   this.service.getVehicleAge().subscribe(res => {
    this.lstVehicleAge =res;
   })
  }

  GetFuelType() {
    this.service.getFuelType().subscribe(res => {
      this.lstFuelType = res;
      this.FuelType = this.lstFuelType[0].fueltypeId;
    });
  }

  GetVehicleTypeType() {
    this.service.getVehicleType().subscribe(res => {
      this.lstVehicleType = res;
      this.VId = this.lstVehicleType[0].vehicleTypeId;
      this.ChangeInsuranceType();
    });
  }

  GetState() {
    this.service.getState().subscribe(res => {
      this.lstState = res;
      this.RTO = this.lstState[0].stateId;
      this.GetRTODetails();
    })
  }

  GetRTODetails()
  {
    this.service.getRTODetails(this.RTO).subscribe(res => {
      this.lstRTO = res;
    })
   
  }
  onFileChange(event: any, fileflag: number) {
  
    if (event.target.files && event.target.files.length > 0) {
      var file = event.target.files[0];
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (e) => {
        if(fileflag ==1) {
          this.fileByteString1 = reader?.result as string;  
          this.fileName1 = file.name;
          this.fileType1 = file.type;  
        }
        if(fileflag ==2) {
          this.fileByteString2 = reader?.result as string;  
          this.fileName2 = file.name;
          this.fileType2 = file.type;  
        }
        if(fileflag ==3) {
          this.fileByteString3 = reader?.result as string;  
          this.fileName3 = file.name;
          this.fileType3 = file.type;  
        }
          
      };
      
    }
  } 
  ShowPopup1() {
    this.requestForFPQ = true;
  }
  HidePopup1() {
    this.requestForFPQ = false;
  }
  SaveFPQuotation() {
    const reqquotation: RequestQuotationModel =
    {
      comments : this.comments,
      email: this.email,
      idvValue: this.idvValue,
      mobileNo: this.mobileNo,
      name: this.name,
      previousInsurance : {
        content : this.fileByteString1,
        contentType : this.fileType1,
        fileSize : 0,
        name: this.fileName1
      },
      rcFront : {
        content : this.fileByteString2,
        contentType : this.fileType2,
        fileSize : 0,
        name: this.fileName2
      },
      rcBack : {
        content : this.fileByteString3,
        contentType : this.fileType3,
        fileSize : 0,
        name: this.fileName3
      },
    }

    this.service.SaveFPQuotation(reqquotation).subscribe(res =>
      {
        console.log(res);
      })

  }
}
