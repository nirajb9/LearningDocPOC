import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { WebvehicleService } from 'src/app/services/webvehicle.service';
import Validation from 'src/app/utils/validation';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-vehicleinfo-view',
  templateUrl: './vehicleinfo-view.component.html',
  styleUrls: ['./vehicleinfo-view.component.css']
})
export class VehicleinfoViewComponent implements OnInit {

  isVehicleCompany: boolean = false;
  isVehicleModel: boolean = true;
  isVehicleVarient: boolean = true;
  isInsuranceDetails: boolean = true;
  lstVehicleCompany: any = [];
  lstVehicleModel: any = [];
  lstVehicleVarient: any = [];
  lstInsuranceInfo: any = [];

  backVehicleCompany: Number = 0
  backVehicleModel: Number = 0
  backVehicleVarient: Number = 0

  submitted = false;
  typeSelected: string = "ball-spin";
  VId : any;
  title : any;
  lstVehicleType : any = [];
  constructor(private formBuilder: FormBuilder,
    private service: WebvehicleService,
    private spinnerService: NgxSpinnerService,
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.VId = this.route.snapshot.paramMap.get('id');
    this.GetVehicleTypeType();
    this.ChangeInsuranceType();
    
  }
  ChangeInsuranceType()
  {
    if(this.VId=="1") {
      this.title = "Bike Insurance";
    }
    if(this.VId=="2") {
      this.title = "Private Car Insurance";
    }
    if(this.VId=="3") {
      this.title = "GCV Insurance";
    }
    if(this.VId=="4") {
      this.title = "GCV Three Wheeler Insurance";
    }
    if(this.VId=="5") {
      this.title = "Tractor";
    }
    this.GetVehicleCompany();
  }

  CloseSpiner()
  {
    setTimeout(() => {
      this.spinnerService.hide();
    }, 1000);
  }

  GetVehicleCompany() {
    this.HideTabs();
    this.isVehicleCompany = false;
    this.spinnerService.show();
    this.service.getVehicleCompany(this.VId)
      .subscribe(res => {
        this.lstVehicleCompany = res;
        this.CloseSpiner();
      }
      )
  }

  GetVehicleModelByCompanyId(id: Number) {
    this.backVehicleCompany = id;
    this.spinnerService.show();
    this.service.getModelByVCompanyId(id)
      .subscribe(res => {
        this.lstVehicleModel = res;
        this.CloseSpiner();
      }
      )
  }

  GetVehicleVarientByModelId(id: Number) {
   
    this.service.getVarientByVModelId(id)
      .subscribe(res => {
        this.lstVehicleVarient = res;
        this.CloseSpiner();
      }
      )
  }

  GetVehicleModels(companyId: Number) {
    this.HideTabs();
    this.GetVehicleModelByCompanyId(companyId);
    this.isVehicleModel = false;
  }

  GetVehicleVarient(modelId: Number, isBackClick: boolean) {
    this.HideTabs();
    this.backVehicleModel = modelId;
    this.spinnerService.show();
    if(this.VId == "3" || this.VId =="4") {
      if(isBackClick) {
        this.GetVehicleModels(this.backVehicleCompany);
      }
      else {
        this.GetInsuranceDetails(modelId,1)
        this.isInsuranceDetails = false;
      }
      
    }
    else {
      this.GetVehicleVarientByModelId(modelId);
      this.isVehicleVarient = false;
    }
    
  }
  GetInsuranceDetails(varientId: Number, level: Number) {
    this.backVehicleVarient = varientId;
    this.spinnerService.show();
    this.HideTabs();
    this.service.getInsuranceDetails(varientId, 'MP50', level)
      .subscribe(res => {
        this.lstInsuranceInfo = res;
        this.CloseSpiner();
      }
      )
    this.isInsuranceDetails = false;
  }

  HideTabs() {
    this.isVehicleCompany = true;
    this.isVehicleModel = true;
    this.isVehicleVarient = true;
    this.isInsuranceDetails = true;
  }

  onSubmit(): void {
    this.submitted = true;


  }


  opentab(val: any) {
    this.isVehicleCompany = true;
    this.isVehicleModel = true;
    this.isVehicleVarient = true;
    if (val == 1) {
      this.isVehicleCompany = false;
    }
    if (val == 2) {
      this.isVehicleModel = false;
    }
    if (val == 3) {
      this.isVehicleVarient = false;
    }
  }

  GetVehicleTypeType() {
    this.service.getVehicleType().subscribe(res => {
      this.lstVehicleType = res;
      this.VId = this.lstVehicleType[0].vehicleTypeId;
      this.ChangeInsuranceType();
    });
  }
}

