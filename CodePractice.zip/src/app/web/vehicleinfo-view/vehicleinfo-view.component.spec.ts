import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VehicleinfoViewComponent } from './vehicleinfo-view.component';

describe('VehicleinfoViewComponent', () => {
  let component: VehicleinfoViewComponent;
  let fixture: ComponentFixture<VehicleinfoViewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VehicleinfoViewComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VehicleinfoViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
