import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ContactComponent } from 'src/app/web/contact/contact.component';
import { HomeComponent } from 'src/app/web/home/home.component';
import { RegistrationComponent } from 'src/app/web/registration/registration.component';
import { RouterModule, Routes } from '@angular/router';
import { VehicleinfoViewComponent } from './vehicleinfo-view/vehicleinfo-view.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxSpinnerModule } from 'ngx-spinner';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'registration', component: RegistrationComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'vehicleinfo-view/:id', component: VehicleinfoViewComponent }
];

@NgModule({
  declarations: [
    
    ContactComponent,
    HomeComponent,
    RegistrationComponent,
    VehicleinfoViewComponent
    
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    NgxSpinnerModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class WebModule { }
